resources:
-reference boook by Eric Matthes "Python Crash Course"
-python.org